# SQL Proje – DriveFleet Car Rental Dashboard

Grup 5 tarafından geliştirilen araç kiralama yönetim sistemi.

## Proje Yapısı

```
SQL_Proje/
├── backend/
│   ├── server_admin.js              # Express.js API sunucusu
│   ├── drivefleet.sql               # Veritabanı şeması ve örnek veriler
│   ├── car_rental_dashboard_admin_checkbox_fix.html  # Admin arayüzü (HTML)
│   ├── package.json                 # Node.js bağımlılıkları
│   └── .gitignore
├── Group5.docx                      # Proje raporu
└── Sql Er Diagram.pdf               # ER Diyagramı
```

## Kurulum

### Gereksinimler
- Node.js (v18+)
- MySQL

### Adımlar

1. Bağımlılıkları yükle:
   ```bash
   cd backend
   npm install
   ```

2. MySQL'de veritabanını oluştur:
   ```sql
   source drivefleet.sql;
   ```

3. `server_admin.js` içindeki veritabanı bağlantı bilgilerini kendi ortamına göre güncelle.

4. Sunucuyu başlat:
   ```bash
   node server_admin.js
   ```

5. Tarayıcıda `car_rental_dashboard_admin_checkbox_fix.html` dosyasını aç.
